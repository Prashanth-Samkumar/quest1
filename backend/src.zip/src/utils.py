import re

def singleton(cls):
    instances = {}
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return get_instance
def get_clean_id(link: str) -> str:
    """
    Extract a unique, filesystem-safe ID from a video URL.
    Supports YouTube, OK.ru, and falls back to cleaning generic URLs.
    """
    # Try to extract YouTube video ID (11 chars)
    yt_match = re.search(r'(?:v=|\/)([a-zA-Z0-9_-]{11})(?:\?|&|$)', link)
    if yt_match:
        return yt_match.group(1)
        
    # Try to extract OK.ru video ID
    ok_match = re.search(r'video\/(\d+)', link)
    if ok_match:
        return ok_match.group(1)
        
    # Fallback to general clean link
    clean_link = re.sub(r'https?://(?:www\.)?', '', link)
    clean_link = re.sub(r'[^a-zA-Z0-9_-]', '_', clean_link)
    return clean_link[:50]

def get_video_filename(link: str) -> str:
    """Get the video filename path for a given link."""
    return f"output/{get_clean_id(link)}_video.mp4"

def get_audio_filename(link: str) -> str:
    """Get the audio filename path for a given link."""
    return f"output/{get_clean_id(link)}_audio.wav"

def get_transcript_filename(link: str) -> str:
    """Get the transcript JSON filename path for a given link."""
    return f"output/{get_clean_id(link)}_trans.json"
