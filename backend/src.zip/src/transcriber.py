from schemas import WordTiming
from faster_whisper import WhisperModel
from typing import List
import os
import sys

def transcribe_audio(audio_path: str, model ) -> List[WordTiming]:
    print(audio_path)
    segments, info = model.transcribe(
        audio_path,
        word_timestamps=True,
        vad_filter=True,   
    )

    word_timings: List[WordTiming] = []
    for segment in segments:
        if segment.words is None:
            continue
        for w in segment.words:
            word_timings.append(
                WordTiming(
                    word=w.word.strip(),
                    start=w.start,
                    end=w.end,
                    segment_text=segment.text.strip(),
                )
            )

    return word_timings


def main():
    # Audio file path
    audio_path = "video_worst.wav"
    
    # Check if audio file exists
    if not os.path.exists(audio_path):
        print(f"❌ Audio file not found: {audio_path}")
        print("Please run download script first to get audio file.")
        sys.exit(1)
    
    print("🔊 Loading Whisper model...")
    
    # Create model instance
    model = WhisperModel(
        "base",
        device="cpu",
        compute_type="int8"
    )
    
    print("🎤 Transcribing audio...")
    
    # Transcribe audio
    word_timings = transcribe_audio(audio_path, model)
    
    if not word_timings:
        print("❌ No words transcribed")
        sys.exit(1)
    
    print(f"✅ Transcribed {len(word_timings)} words")
    print(f"📝 Full text:")
    print("-" * 50)
    
    # Print the full text
    full_text = " ".join(w.word for w in word_timings)
    print(full_text)
    
    print("-" * 50)
    print("\n📊 Word-level timestamps (first 10 words):")
    
    # Print word-level timestamps
    for i, word in enumerate(word_timings[:10]):
        print(f"  {i+1:2d}. {word.word:15s} {word.start:6.2f}s - {word.end:6.2f}s")
    
    if len(word_timings) > 10:
        print(f"  ... and {len(word_timings) - 10} more words")
    
    # Search for specific text
    search_text = "my mind rebels at stagnation"
    print(f"\n🔍 Searching for: '{search_text}'")
    
    found = None
    for word in word_timings:
        if search_text.lower() in word.word.lower():
            found = word
            break
    
    if found:
        print(f"✅ Found at: {found.start:.2f}s - {found.end:.2f}s")
        print(f"📝 Word: '{found.word}'")
        print(f"📄 Segment: '{found.segment_text}'")
    else:
        print("❌ Not found")
    
    return word_timings


if __name__ == "__main__":
    main()
